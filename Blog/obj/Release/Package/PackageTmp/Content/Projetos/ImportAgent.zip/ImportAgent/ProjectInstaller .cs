﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration.Install;
using System.ServiceProcess;
using System.ComponentModel;

namespace ImportAgent
{
    [RunInstaller(true)]
    public class InstaladorServico : Installer
    {
        private ServiceInstaller serviceInstaller;
        private ServiceProcessInstaller serviceProcessInstaller;

        public InstaladorServico() 
        {
            InitializeComponent();
        }

        private void InitializeComponent() 
        {
            this.serviceInstaller = new ServiceInstaller();
            this.serviceProcessInstaller = new ServiceProcessInstaller();            
            
            this.serviceInstaller.Description = "Desconpacta arquivos zipados enviados pelo credor na pasta FTP para o IMPORT AGENT";
            this.serviceInstaller.DisplayName = "Laserfiche Descompactador FTP";
            this.serviceInstaller.ServiceName = "ImportAgentDescompactador";
            this.serviceInstaller.StartType = ServiceStartMode.Automatic;

            this.serviceProcessInstaller.Account = ServiceAccount.LocalSystem;
            this.serviceProcessInstaller.Password = null;
            this.serviceProcessInstaller.Username = null;           

            this.Installers.AddRange(new Installer[] { this.serviceProcessInstaller, this.serviceInstaller });
        }
    }
}
