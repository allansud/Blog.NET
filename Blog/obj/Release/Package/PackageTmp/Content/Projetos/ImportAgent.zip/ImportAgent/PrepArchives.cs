﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.IO.Compression;
using System.ServiceProcess;
using System.Threading;

namespace ImportAgent
{
    public class PrepArchives : ServiceBase
    {
        private Thread _ThreadVerificacao; 

        static void Main() 
        {
            ServiceBase[] serviceToRun;
            serviceToRun = new ServiceBase[] { new PrepArchives() };
            ServiceBase.Run(serviceToRun);
        }

        public static String formataData(String data) 
        {
            DateTime dt = Convert.ToDateTime(data);
            String dataFormatada = dt.ToString("dd/MM/yyyy");

            return dataFormatada;
        }

        public PrepArchives() 
        {
            InitializeComponent();

            this.AutoLog = false;

            if (!System.Diagnostics.EventLog.SourceExists("LogDescompactador"))
            {
                System.Diagnostics.EventLog.CreateEventSource("LogDescompactador", "LogDescompactadorAgent");
            }

            System.Diagnostics.EventLog ev = new System.Diagnostics.EventLog();
            ev.Source = "LogDescompactador";
        }

        private void InitializeComponent() 
        {
            this.ServiceName = "Descompactador LF";
        }

        protected void StartThread() 
        {
            string pastaCaminho = @"D:\COMPARTILHAMENTOS\FTP\FTP GECOV\bradesco";
            string pathString = @"F:\ImportAgent";

            FileStream fs2 = new FileStream(@"F:\ImportAgent\Logs" + @"\ServicoDescompactadorThread.txt", FileMode.OpenOrCreate, FileAccess.Write);
            StreamWriter sw2 = new StreamWriter(fs2);

            sw2.BaseStream.Seek(0, SeekOrigin.End);
            sw2.WriteLine("ServicoDescompactadorThreat: escreveu as " + DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString() + "\n");
            sw2.Flush();
            sw2.Close();

            try
            {
                var files = Directory.GetFiles(pastaCaminho, "*.zip");

                foreach (var file in files)
                {
                    ZipFile.ExtractToDirectory(file, pathString);
                    File.Delete(file);
                }
            }
            catch (Exception ex)
            {
                FileStream fs1 = new FileStream(@"F:\ImportAgent\Logs" + @"\ERRO.txt", FileMode.OpenOrCreate, FileAccess.Write);
                StreamWriter sw1 = new StreamWriter(fs1);

                sw1.BaseStream.Seek(0, SeekOrigin.End);
                sw1.WriteLine("ERRO: escreveu as " + DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString() + "\n" + "{0} ", ex);
                sw1.Flush();
                sw1.Close();
            }
        }

        protected override void OnStart(string[] args)
        {
            FileStream fs3 = new FileStream(@"F:\ImportAgent\Logs" + @"\ServicoDescompactadorFTPIniciado.txt", FileMode.OpenOrCreate, FileAccess.Write);
            StreamWriter sw3 = new StreamWriter(fs3);

            sw3.BaseStream.Seek(0, SeekOrigin.End);
            sw3.WriteLine("DescompactadorFTP: Serviço iniciou as " + DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString() + "\n");
            sw3.Flush();
            sw3.Close();

            _ThreadVerificacao = new Thread(ChecaHoraraio);
            _ThreadVerificacao.Start();
        }

        protected override void OnStop()
        {
            FileStream fs4 = new FileStream(@"F:\ImportAgent\Logs" + "\\ServicoDescompactadorFTPParado.txt", FileMode.OpenOrCreate, FileAccess.Write);
            StreamWriter sw4 = new StreamWriter(fs4);

            sw4.BaseStream.Seek(0, SeekOrigin.End);
            sw4.WriteLine("DescompactadorFTP: Serviço parou as " + DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString() + "\n");
            sw4.Flush();
            sw4.Close();

            _ThreadVerificacao.Abort();
        }

        protected void ChecaHoraraio() 
        {
            while (true) 
            {
                if (DateTime.Now.Hour >= 1) 
                {
                    StartThread();
                }
                Thread.Sleep(900000);
            }
        }
    }
}
